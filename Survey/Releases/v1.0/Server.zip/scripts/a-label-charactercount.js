/*
  functionality:


  Parameters: 


  Event Handlers:


  Configuration:
  {}

*/

define(
    function () {

        function aLabelCharacterCount() {

        }

        return aLabelCharacterCount;

    });