/*
  functionality:

  switching states

  Parameters: 


  Event Handlers:


  Configuration:
  {}

*/

define(
    function () {

        function aIconMultiState() {

        }

        return aIconMultiState;

    });