require(['domReady'], function (domReady) {
    domReady(function () {
        app.Init();
    })
});