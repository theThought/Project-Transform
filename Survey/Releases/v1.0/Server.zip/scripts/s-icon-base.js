/*
  functionality:

  loading state images

  Parameters: 


  Event Handlers:


  Configuration:
  {}

*/

define(
    function () {

        function sIconBase() {

        }

        return sIconBase;

    });