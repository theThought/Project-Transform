/*
  functionality:

  balancing space for each option

  Parameters: 


  Event Handlers:


  Configuration:
  {}

*/

define(['component'],
    function (component) {

        /**
         * Organism: Option List
         *
         * @constructor
         */

        function oOptionList() {
        }

        return oOptionList;

    });