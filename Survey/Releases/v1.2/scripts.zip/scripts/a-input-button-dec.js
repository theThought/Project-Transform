/*
  functionality:

  switching states

  Parameters: 


  Event Handlers:


  Configuration:
  {}

*/

define(['component'],
    function (component) {

        /**
         * Atom: Decrement Button
         *
         * @constructor
         * @param {String} id - element id
         * @param {String} group - question group
         */

        function aInputButtonDec(id, group) {
            this.id = id;
            this.group = group;
            this.element = document.querySelector('div[data-questiongroup="' + this.group + '"] button.a-button-preterminator');
            this.defaultsymbol = '&laquo;'; // default arrow appearance

            this.symbol(this.defaultsymbol);
            this.configureIncomingEventListeners();
        }

        aInputButtonDec.prototype = Object.create(component.prototype);

        aInputButtonDec.prototype.symbol = function (symbol) {
            this.element.innerHTML = symbol;
        }

        aInputButtonDec.prototype.configureIncomingEventListeners = function () {
            // for each event listener there must be a corresponding event handler
            document.addEventListener("click", this, false);
        }

        aInputButtonDec.prototype.handleEvent = function (event) {
            switch (event.type) {
                case "click":
                    this.onClick(event);
                    break;
            }
        }

        aInputButtonDec.prototype.onClick = function (event) {
            if (event.target === this.element) {

                var decrementValueEvent = new CustomEvent(this.group + '_decrementValue', {
                    bubbles: true,
                    detail: this
                });
                document.dispatchEvent(decrementValueEvent);
            }
        }

        return aInputButtonDec;

    });