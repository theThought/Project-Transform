require(['domReady'], function (domReady) {
    domReady(function () {
        // anything that needs to be run on DOM completion
    })
});