require(['domready'], function (domReady) {
    domReady(function () {
        app.checkProperties();
    })
});