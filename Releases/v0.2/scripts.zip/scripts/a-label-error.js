/*
  functionality:

  none expected, this is just a placeholder

  Parameters: 


  Event Handlers:


  Configuration:
  {}

*/

define(
    function () {

        function aLabelError() {

        }

        return aLabelError;

    });
