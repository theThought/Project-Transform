/*
  functionality:

  none expected, this is just a placeholder

  Parameters: 


  Event Handlers:


  Configuration:
  {"labels":{"pre":"", "post":"", charactercount:null}}

*/

define(
    [
        'o-input-multilineedit',
        'a-label-error',
        'a-label-instruction',
        'a-label-question',
    ],
    function () {

        function tQuestionMultilineedit() {

        }

        return tQuestionMultilineedit;

    });


/*
a-input-multilineedit
+
a-label-charactercount
=
m-input-multilineedit
+
m-option-base
=
o-input-multilineedit
+
a-label-question
+
a-label-error
+ 
a-label-instruction
=
t-question-multilineedit
*/