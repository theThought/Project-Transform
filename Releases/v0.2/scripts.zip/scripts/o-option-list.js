/*
  functionality:

  balancing space for each option

  Parameters: 


  Event Handlers:


  Configuration:
  {}

*/

define(
    function () {

        function oOptionList() {

        }

        return oOptionList;

    });