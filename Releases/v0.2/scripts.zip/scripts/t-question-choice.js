/*
  functionality:

  none expected, this is just a placeholder

  Parameters: 


  Event Handlers:


  Configuration:
  {"balanced": true}

*/

define(
    function () {

        function tQuestionChoice() {

        }

        return tQuestionChoice;

    });