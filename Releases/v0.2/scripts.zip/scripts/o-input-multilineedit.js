/*
  functionality:

  character countdown

  Parameters: 


  Event Handlers:


  Configuration:
  {}

*/

define(
    [
        'a-input-multilineedit',
        'm-option-base',
    ],
    function () {

        function aInputMultilineEdit() {

        }

        return aInputMultilineEdit;

    });